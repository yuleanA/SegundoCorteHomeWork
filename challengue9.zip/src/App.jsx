import { TodoApp } from "./components/TodoApp";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <TodoApp />
    </div>
  );
}
