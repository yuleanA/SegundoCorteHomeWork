import { Father } from "./Father";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <Father />
    </div>
  );
}
